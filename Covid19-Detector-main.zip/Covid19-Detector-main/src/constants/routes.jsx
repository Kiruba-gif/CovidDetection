export const API_ROOT = 'https://covid-19-detector-model.herokuapp.com';
export const API_IMAGE_UPLOAD = `${API_ROOT}/api/posts/`;
